
.include "m328Pdef.inc"


.equ F_CPU        = 16000000          ; clock do Uno


.equ SIMULACAO    = 0

.if SIMULACAO
.equ UBRR_VAL     = 0                 ; 62500 bps: strings saem em poucos ciclos
.equ OCR1A_VAL    = 624               ; interrupcao a cada 10 ms em vez de 1 s
.else
.equ BAUD         = 9600              ; velocidade da serial
.equ UBRR_VAL     = (F_CPU/16/BAUD)-1 ; = 103 para 9600 bps (ver datasheet)
; Timer1 em CTC com prescaler 256:
;   16.000.000 / 256 = 62.500 contagens por segundo
;   OCR1A = 62.500 - 1 = 62.499  ->  uma interrupcao por segundo
.equ OCR1A_VAL    = 62499
.endif

.equ NUM_ESTADOS  = 6                 ; quantidade de linhas da tabela
.equ TAM_ESTADO   = 4                 ; bytes por linha (dur, byteA, byteB, 0)

; Bits do Byte A (595 #1)
.equ S1_VM = (1<<0)
.equ S1_AM = (1<<1)
.equ S1_VD = (1<<2)
.equ S2_VM = (1<<3)
.equ S2_AM = (1<<4)
.equ S2_VD = (1<<5)
.equ P_VM  = (1<<6)
.equ P_VD  = (1<<7)

; Bits do Byte B (595 #2)
.equ S3_VM = (1<<0)
.equ S3_AM = (1<<1)
.equ S3_VD = (1<<2)
.equ S4_VM = (1<<3)
.equ S4_AM = (1<<4)
.equ S4_VD = (1<<5)

; Pino de latch dos 74HC595
.equ LATCH = PB2


.def tmp    = r16   ; temporario de uso geral
.def tmp2   = r17   ; segundo temporario
.def estado = r18   ; indice do estado atual (0..NUM_ESTADOS-1)
.def seg    = r19   ; segundos restantes no estado atual
.def ledsA  = r20   ; byte de LEDs para o 595 #1
.def ledsB  = r21   ; byte de LEDs para o 595 #2
.def zero   = r22   ; registrador sempre com valor 0 (usado em adc)


.dseg
tx_ptr: .byte 2     ; ponteiro (endereco em flash) do proximo caractere a enviar

.cseg
.org 0x0000
    rjmp reset                  ; vetor de reset

.org OC1Aaddr
    rjmp isr_timer1             ; Timer1 Compare Match A -> a cada 1 s

.org UDREaddr
    rjmp isr_udre               ; USART Data Register Empty -> proximo char

.org INT_VECTORS_SIZE           ; o codigo comeca depois da tabela de vetores

reset:
    ldi  tmp, high(RAMEND)
    out  SPH, tmp
    ldi  tmp, low(RAMEND)
    out  SPL, tmp

    clr  zero                   ; registrador zero = 0

    ; portas 
    ; PB2 = latch, PB3 = MOSI, PB5 = SCK como saidas.
    ; PB2 (SS) precisa ser saida para a SPI funcionar como mestre.
    ldi  tmp, (1<<PB2)|(1<<PB3)|(1<<PB5)
    out  DDRB, tmp
    cbi  PORTB, LATCH           ; latch comeca em nivel baixo

    ldi  tmp, 0x0F              ; PC0..PC3 -> BCD das unidades
    out  DDRC, tmp

    ldi  tmp, 0xF0              ; PD4..PD7 -> BCD das dezenas
    out  DDRD, tmp

    ;SPI (para os 74HC595) 
    ; SPE = habilita, MSTR = mestre, SPR0 = clock fosc/16 = 1 MHz
    ; Modo 0 (CPOL=0, CPHA=0), MSB primeiro: compativel com o 74HC595.
    ldi  tmp, (1<<SPE)|(1<<MSTR)|(1<<SPR0)
    out  SPCR, tmp

    ; USART0 (9600 bps, 8 bits, sem paridade, 1 stop)
    ldi  tmp, high(UBRR_VAL)
    sts  UBRR0H, tmp
    ldi  tmp, low(UBRR_VAL)
    sts  UBRR0L, tmp
    ldi  tmp, (1<<TXEN0)        ; habilita apenas o transmissor
    sts  UCSR0B, tmp
    ldi  tmp, (1<<UCSZ01)|(1<<UCSZ00)   ; 8 bits de dados
    sts  UCSR0C, tmp

    ; mensagem de abertura (enviada por polling, antes das interrupcoes)
    ldi  ZL, low(str_banner*2)
    ldi  ZH, high(str_banner*2)
    rcall envia_string_polling

    ; estado inicial
    clr  estado                 ; comeca no estado 1 (indice 0)
    rcall carrega_estado        ; le a tabela, acende LEDs, agenda serial
    rcall mostra_display        ; mostra os segundos do primeiro estado

    ;  Timer1: CTC, prescaler 256, interrupcao no compare A 
    ldi  tmp, 0
    sts  TCCR1A, tmp            ; modo normal de saida (sem PWM)
    ; Escrita de 16 bits: sempre o byte alto primeiro
    ldi  tmp, high(OCR1A_VAL)
    sts  OCR1AH, tmp
    ldi  tmp, low(OCR1A_VAL)
    sts  OCR1AL, tmp
    ldi  tmp, (1<<WGM12)|(1<<CS12)      ; WGM12 = CTC; CS12 = prescaler 256
    sts  TCCR1B, tmp
    ldi  tmp, (1<<OCIE1A)       ; habilita a interrupcao de compare A
    sts  TIMSK1, tmp

    sei                         ; habilita interrupcoes globais


loop:
    rjmp loop

; ISR DO TIMER1 - executada uma vez por segundo
isr_timer1:
    ; salva os registradores que a rotina usa (e o SREG)
    push tmp
    in   tmp, SREG
    push tmp
    push tmp2
    push ZL
    push ZH

    dec  seg                    ; passou 1 segundo
    brne t1_atualiza            ; ainda ha tempo: so atualiza o display

    ; ---- contador chegou a zero: proximo estado -------------------------
    inc  estado
    cpi  estado, NUM_ESTADOS
    brlo t1_carrega             ; estado < NUM_ESTADOS -> ok
    clr  estado                 ; passou do ultimo -> volta ao estado 1
t1_carrega:
    rcall carrega_estado        ; carrega seg/LEDs e dispara a serial

t1_atualiza:
    rcall mostra_display        ; mostra os segundos restantes

    ; restaura os registradores
    pop  ZH
    pop  ZL
    pop  tmp2
    pop  tmp
    out  SREG, tmp
    pop  tmp
    reti


isr_udre:
    push tmp
    in   tmp, SREG
    push tmp
    push ZL
    push ZH

    lds  ZL, tx_ptr             ; recupera o ponteiro da string
    lds  ZH, tx_ptr+1
    lpm  tmp, Z+                ; le o caractere e avanca o ponteiro
    tst  tmp
    breq udre_fim               ; 0 = fim da string

    sts  UDR0, tmp              ; envia o caractere
    sts  tx_ptr, ZL             ; guarda o ponteiro avancado
    sts  tx_ptr+1, ZH
    rjmp udre_sai

udre_fim:
    lds  tmp, UCSR0B
    cbr  tmp, (1<<UDRIE0)       ; desliga a interrupcao UDRE
    sts  UCSR0B, tmp

udre_sai:
    pop  ZH
    pop  ZL
    pop  tmp
    out  SREG, tmp
    pop  tmp
    reti


carrega_estado:
    ; Z = endereco(tabela_estados) + estado * TAM_ESTADO
    ldi  ZL, low(tabela_estados*2)      ; *2: endereco em bytes para o lpm
    ldi  ZH, high(tabela_estados*2)
    mov  tmp, estado
    lsl  tmp                    ; x2
    lsl  tmp                    ; x4  (TAM_ESTADO = 4)
    add  ZL, tmp
    adc  ZH, zero               ; propaga o carry para o byte alto

    lpm  seg,   Z+              ; duracao do estado em segundos
    lpm  ledsA, Z+              ; byte do 595 #1
    lpm  ledsB, Z+              ; byte do 595 #2

    rcall envia_leds            ; acende os LEDs do novo estado


    ldi  ZL, low(tab_strings*2)
    ldi  ZH, high(tab_strings*2)
    mov  tmp, estado
    lsl  tmp                    ; x2 (cada ponteiro tem 2 bytes)
    add  ZL, tmp
    adc  ZH, zero
    lpm  tmp,  Z+               ; byte baixo do endereco da string
    lpm  tmp2, Z                ; byte alto
    sts  tx_ptr,   tmp
    sts  tx_ptr+1, tmp2

    lds  tmp, UCSR0B
    sbr  tmp, (1<<UDRIE0)
    sts  UCSR0B, tmp
    ret


envia_leds:
    out  SPDR, ledsB            ; primeiro o byte do 595 mais distante (#2)
    rcall spi_espera
    out  SPDR, ledsA            ; depois o byte do 595 #1
    rcall spi_espera
    sbi  PORTB, LATCH           ; pulso no RCLK: os 16 bits aparecem nas saidas
    cbi  PORTB, LATCH
    ret

spi_espera:
    in   tmp, SPSR
    sbrs tmp, SPIF              ; pula o rjmp se SPIF = 1 (terminou)
    rjmp spi_espera
    ret

mostra_display:
    mov  tmp, seg               ; tmp = valor a mostrar
    clr  tmp2                   ; tmp2 = dezenas
md_loop:
    cpi  tmp, 10
    brlo md_pronto              ; tmp < 10 -> terminou a divisao
    subi tmp, 10                ; tmp = tmp - 10
    inc  tmp2                   ; dezenas++
    rjmp md_loop
md_pronto:
    out  PORTC, tmp             ; unidades em PC0..PC3 (PC4/PC5 ficam em 0)

    swap tmp2                   ; dezenas para o nibble alto
    in   tmp, PORTD
    andi tmp, 0x0F              ; preserva PD0..PD3 (PD0/PD1 sao a serial)
    or   tmp, tmp2
    out  PORTD, tmp             ; dezenas em PD4..PD7
    ret

envia_string_polling:
esp_loop:
    lpm  tmp, Z+
    tst  tmp
    breq esp_fim                ; 0 = fim
esp_espera:
    lds  tmp2, UCSR0A
    sbrs tmp2, UDRE0            ; espera o registrador esvaziar
    rjmp esp_espera
    sts  UDR0, tmp
    rjmp esp_loop
esp_fim:
    ret

;
;  Estado (codigo) | S1 | S2 | S3 | S4 | P  | Duracao | Quem passa
;    q1   (000)    | Vm | Vm | Vd | Vd | Vm |  53 s   | avenida nos 2 sentidos
;    q2   (001)    | Vm | Vm | Am | Am | Vm |   4 s   | avenida fechando
;    q3   (010)    | Vd | Vm | Vm | Vm | Vd |  48 s   | rua lateral + pedestre
;    q4   (011)    | Am | Vm | Vm | Vm | Vd |   4 s   | lateral fechando
;    q5   (100)    | Vm | Vd | Vd | Vm | Vm |  23 s   | sobe: reto + conversao
;    q6   (101)    | Vm | Am | Vd | Vm | Vm |   4 s   | conversao fechando
;  Ciclo total: 136 s. Depois de q6 volta a q1.
;
;  Pedestre (P): fica verde enquanto S3 e S4 estao vermelhos (q3 e q4).
;  Se o levantamento mostrar que P ja abre no amarelo (q2), troque P_VM por
;  P_VD na linha de q2. Se as duas faixas fecharem em momentos diferentes,
;  use os bits 6 e 7 do Byte B para a segunda faixa.
tabela_estados:
    ;   dur  Byte A (S1, S2, P)       Byte B (S3, S4)      reservado
    .db 53,  S1_VM|S2_VM|P_VM,        S3_VD|S4_VD,         0   ; q1
    .db  4,  S1_VM|S2_VM|P_VM,        S3_AM|S4_AM,         0   ; q2
    .db 48,  S1_VD|S2_VM|P_VD,        S3_VM|S4_VM,         0   ; q3
    .db  4,  S1_AM|S2_VM|P_VD,        S3_VM|S4_VM,         0   ; q4
    .db 23,  S1_VM|S2_VD|P_VM,        S3_VD|S4_VM,         0   ; q5
    .db  4,  S1_VM|S2_AM|P_VM,        S3_VD|S4_VM,         0   ; q6


tab_strings:
    .dw str_e1*2, str_e2*2, str_e3*2
    .dw str_e4*2, str_e5*2, str_e6*2


str_banner:
    .db "Semaforos - Av. Alvaro Otacilio x R. Prof. Sandoval Arroxelas - Maceio/AL", 13, 10, 0

str_e1: .db "q1 (53s): S1 - Vermelho; S2 - Vermelho; S3 - Verde; S4 - Verde; P - Vermelho", 13, 10, 0
str_e2: .db "q2 (4s): S1 - Vermelho; S2 - Vermelho; S3 - Amarelo; S4 - Amarelo; P - Vermelho", 13, 10, 0
str_e3: .db "q3 (48s): S1 - Verde; S2 - Vermelho; S3 - Vermelho; S4 - Vermelho; P - Verde", 13, 10, 0
str_e4: .db "q4 (4s): S1 - Amarelo; S2 - Vermelho; S3 - Vermelho; S4 - Vermelho; P - Verde", 13, 10, 0
str_e5: .db "q5 (23s): S1 - Vermelho; S2 - Verde; S3 - Verde; S4 - Vermelho; P - Vermelho", 13, 10, 0
str_e6: .db "q6 (4s): S1 - Vermelho; S2 - Amarelo; S3 - Verde; S4 - Vermelho; P - Vermelho", 13, 10, 0